"""Вход на страницу через Active Directory (LDAP bind) + проверка доступа (список пользователей и/или группа AD)."""
import logging
import ssl

from ldap3 import NONE, SUBTREE, Connection, Server, Tls
from ldap3.core.exceptions import LDAPException
from ldap3.utils.conv import escape_filter_chars

from .config import settings

log = logging.getLogger("cleaner.auth")

# Правило LDAP_MATCHING_RULE_IN_CHAIN — учитывает вложенные группы AD
IN_CHAIN = "1.2.840.113556.1.4.1941"


class AuthError(Exception):
    pass


def normalize_username(raw: str) -> str:
    """'NARVAHAIGLA\\abelyaev', 'abelyaev@narvahaigla.ee', 'abelyaev' -> 'abelyaev'."""
    name = (raw or "").strip()
    if "\\" in name:
        name = name.split("\\", 1)[1]
    if "@" in name:
        name = name.split("@", 1)[0]
    return name.lower()


def _server() -> Server:
    tls = Tls(validate=ssl.CERT_REQUIRED if settings.ldap_verify_tls else ssl.CERT_NONE)
    return Server(
        settings.ldap_server,
        use_ssl=settings.ldap_server.lower().startswith("ldaps://"),
        tls=tls,
        get_info=NONE,
        connect_timeout=5,
    )


def _group_dn(conn: Connection, group: str) -> str | None:
    if "=" in group:  # уже DN
        return group
    flt = f"(&(objectClass=group)(|(cn={escape_filter_chars(group)})(sAMAccountName={escape_filter_chars(group)})))"
    conn.search(settings.ldap_base_dn, flt, SUBTREE, attributes=["distinguishedName"])
    if conn.entries:
        return conn.entries[0].entry_dn
    return None


def authenticate(username: str, password: str) -> dict:
    if not username or not password:
        raise AuthError("Введите логин и пароль")
    if not settings.ldap_server or not settings.ldap_domain:
        raise AuthError("Вход не настроен: не заданы LDAP_SERVER и LDAP_DOMAIN")
    if not settings.ldap_allowed_users and not settings.ldap_allowed_group:
        raise AuthError("Вход не настроен: задайте LDAP_ALLOWED_USERS или LDAP_ALLOWED_GROUP")

    sam = normalize_username(username)
    conn = Connection(
        _server(),
        user=f"{sam}@{settings.ldap_domain}",
        password=password,
        auto_bind=False,
        receive_timeout=10,
        raise_exceptions=False,
    )
    try:
        conn.open()
        if settings.ldap_start_tls and not settings.ldap_server.lower().startswith("ldaps://"):
            conn.start_tls()
        if not conn.bind():
            log.warning("Неудачный вход: %s (%s)", sam, conn.result.get("description"))
            raise AuthError("Неверный логин или пароль")

        safe = escape_filter_chars(sam)
        conn.search(
            settings.ldap_base_dn,
            f"(&(objectClass=user)(sAMAccountName={safe}))",
            SUBTREE,
            attributes=["displayName"],
        )
        if not conn.entries:
            raise AuthError("Пользователь не найден в AD")
        entry = conn.entries[0]
        display = str(entry.displayName) if "displayName" in entry and entry.displayName.value else sam

        allowed = sam in settings.ldap_allowed_users
        if not allowed and settings.ldap_allowed_group:
            gdn = _group_dn(conn, settings.ldap_allowed_group)
            if gdn:
                conn.search(
                    settings.ldap_base_dn,
                    f"(&(sAMAccountName={safe})(memberOf:{IN_CHAIN}:={escape_filter_chars(gdn)}))",
                    SUBTREE,
                    attributes=["sAMAccountName"],
                )
                allowed = bool(conn.entries)
            else:
                log.error("Группа %s не найдена в AD", settings.ldap_allowed_group)

        if not allowed:
            log.warning("Вход запрещён (нет в списке/группе): %s", sam)
            raise AuthError("У вас нет доступа к Cleaner")

        log.info("Вход выполнен: %s", sam)
        return {"username": sam, "name": display}
    except LDAPException as exc:
        log.error("Ошибка LDAP: %s", exc)
        raise AuthError("Контроллер домена недоступен или отклонил подключение") from exc
    finally:
        try:
            conn.unbind()
        except Exception:
            pass
