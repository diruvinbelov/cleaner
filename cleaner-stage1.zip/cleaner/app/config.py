"""Настройки приложения. Все значения берутся из переменных окружения (в Coolify — раздел Environment Variables)."""
import os


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(_env(name, str(default)))
    except ValueError:
        return default


def _list(name: str) -> list[str]:
    return [x.strip().lower() for x in _env(name).split(",") if x.strip()]


class Settings:
    def __init__(self) -> None:
        # Общие
        self.data_dir = _env("DATA_DIR", "/data")
        self.secret_key = _env("SECRET_KEY")
        self.session_hours = _int("SESSION_HOURS", 12)
        self.cookie_secure = _bool("COOKIE_SECURE", False)

        # GLPI
        url = _env("GLPI_URL").rstrip("/")
        if url and not url.endswith("apirest.php"):
            url = url + "/apirest.php"
        self.glpi_url = url
        self.glpi_app_token = _env("GLPI_APP_TOKEN")
        self.glpi_user_token = _env("GLPI_USER_TOKEN")
        self.glpi_verify_tls = _bool("GLPI_VERIFY_TLS", True)
        self.glpi_name_prefix = _env("GLPI_NAME_PREFIX", "WS")
        self.glpi_state_name = _env("GLPI_STATE_NAME", "В работе")
        self.glpi_concurrency = _int("GLPI_CONCURRENCY", 10)

        # AD / LDAP (вход на страницу)
        self.ldap_server = _env("LDAP_SERVER")  # ldaps://svds1.narvahaigla.ee
        self.ldap_domain = _env("LDAP_DOMAIN")  # narvahaigla.ee
        self.ldap_base_dn = _env("LDAP_BASE_DN") or ",".join(
            f"DC={part}" for part in self.ldap_domain.split(".") if part
        )
        self.ldap_verify_tls = _bool("LDAP_VERIFY_TLS", False)
        self.ldap_start_tls = _bool("LDAP_START_TLS", False)
        self.ldap_allowed_users = _list("LDAP_ALLOWED_USERS")  # abelyaev,ivanov
        self.ldap_allowed_group = _env("LDAP_ALLOWED_GROUP")  # Cleaner-Admins или полный DN

        # Проверка доступности компьютеров
        self.ssh_port = _int("SSH_PORT", 22)
        self.check_timeout = float(_env("CHECK_TIMEOUT", "2") or 2)
        self.check_concurrency = _int("CHECK_CONCURRENCY", 64)

        # Порог «старой» инвентаризации, дней (подсветка ⚠)
        self.inventory_warn_days = _int("INVENTORY_WARN_DAYS", 14)


settings = Settings()
