"""Загрузка компьютеров и диска C: из GLPI REST API (GLPI 10)."""
import asyncio
import ipaddress
import logging

import httpx

from .config import settings

log = logging.getLogger("cleaner.glpi")

SEP = "$$##$$"  # разделитель многозначных полей в поиске GLPI

# Нужные поля поиска: (таблица, поле) -> ID поиска определяется автоматически через listSearchOptions
WANTED = {
    "name": ("glpi_computers", "name"),
    "location": ("glpi_locations", "completename"),
    "state": ("glpi_states", "completename"),
    "inventory": ("glpi_computers", "last_inventory_update"),
    "ip": ("glpi_ipaddresses", "name"),
}
# Значения по умолчанию для GLPI 10, если автоопределение не сработало
DEFAULT_IDS = {"name": 1, "location": 3, "state": 31, "inventory": 9, "ip": 126}


class GlpiError(Exception):
    pass


def _split(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        items = value
    else:
        items = str(value).split(SEP)
    return [str(x).strip() for x in items if x is not None and str(x).strip()]


def _clean_ips(value) -> list[str]:
    result: list[str] = []
    for raw in _split(value):
        try:
            ip = ipaddress.ip_address(raw)
        except ValueError:
            continue
        if ip.version != 4 or ip.is_loopback or ip.is_link_local or ip.is_unspecified:
            continue
        if raw not in result:
            result.append(raw)
    return result


def _state_matches(state: str) -> bool:
    wanted = settings.glpi_state_name.casefold()
    state = (state or "").strip()
    return state.casefold() == wanted or state.split(" > ")[-1].casefold() == wanted


class GlpiClient:
    def __init__(self) -> None:
        if not settings.glpi_url or not settings.glpi_app_token or not settings.glpi_user_token:
            raise GlpiError("GLPI не настроен: задайте GLPI_URL, GLPI_APP_TOKEN, GLPI_USER_TOKEN")
        self.client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "GlpiClient":
        self.client = httpx.AsyncClient(
            base_url=settings.glpi_url,
            headers={"App-Token": settings.glpi_app_token, "Content-Type": "application/json"},
            verify=settings.glpi_verify_tls,
            timeout=httpx.Timeout(30.0, connect=10.0),
        )
        try:
            r = await self.client.get(
                "/initSession", headers={"Authorization": f"user_token {settings.glpi_user_token}"}
            )
        except httpx.HTTPError as exc:
            await self.client.aclose()
            raise GlpiError(f"GLPI недоступен: {exc}") from exc
        if r.status_code != 200:
            await self.client.aclose()
            raise GlpiError(f"GLPI отклонил вход (HTTP {r.status_code}): {r.text[:300]}")
        self.client.headers["Session-Token"] = r.json()["session_token"]
        return self

    async def __aexit__(self, *exc) -> None:
        if self.client:
            try:
                await self.client.get("/killSession")
            except Exception:
                pass
            await self.client.aclose()

    async def _get(self, path: str, params=None):
        assert self.client is not None
        try:
            r = await self.client.get(path, params=params)
        except httpx.HTTPError as exc:
            raise GlpiError(f"GLPI {path}: {exc}") from exc
        if r.status_code not in (200, 206):
            raise GlpiError(f"GLPI {path}: HTTP {r.status_code} {r.text[:300]}")
        return r.json()

    async def search_ids(self) -> dict[str, int]:
        ids: dict[str, int] = {}
        try:
            opts = await self._get("/listSearchOptions/Computer")
            for key, opt in opts.items():
                if not key.isdigit() or not isinstance(opt, dict):
                    continue
                pair = (opt.get("table"), opt.get("field"))
                for name, wanted in WANTED.items():
                    if name not in ids and pair == wanted:
                        ids[name] = int(key)
        except GlpiError as exc:
            log.warning("listSearchOptions не получен, используются ID по умолчанию: %s", exc)
        for name, default in DEFAULT_IDS.items():
            ids.setdefault(name, default)
        return ids

    async def computers(self) -> tuple[list[dict], int]:
        """Возвращает (компьютеры с префиксом WS*, всего записей в GLPI)."""
        ids = await self.search_ids()
        total_glpi = 0
        try:
            r = await self._get("/search/Computer", params={"range": "0-0", "forcedisplay[0]": 2})
            total_glpi = int(r.get("totalcount", 0))
        except GlpiError as exc:
            log.warning("Не удалось получить общее число компьютеров: %s", exc)

        params = {
            "criteria[0][field]": ids["name"],
            "criteria[0][searchtype]": "contains",
            "criteria[0][value]": f"^{settings.glpi_name_prefix}",
            "forcedisplay[0]": 2,
        }
        for i, key in enumerate(("name", "location", "state", "inventory", "ip"), start=1):
            params[f"forcedisplay[{i}]"] = ids[key]

        rows: list[dict] = []
        start, step = 0, 500
        while True:
            params["range"] = f"{start}-{start + step - 1}"
            data = await self._get("/search/Computer", params=params)
            rows.extend(data.get("data") or [])
            total = int(data.get("totalcount", 0))
            start += step
            if start >= total or not data.get("data"):
                break

        prefix = settings.glpi_name_prefix.upper()
        result = []
        for row in rows:
            name = str(row.get(str(ids["name"])) or "").strip()
            state = str(row.get(str(ids["state"])) or "").strip()
            if not name.upper().startswith(prefix) or not _state_matches(state):
                continue
            result.append(
                {
                    "glpi_id": int(row.get("2")),
                    "name": name,
                    "location": (_split(row.get(str(ids["location"]))) or [""])[0],
                    "state": state,
                    "last_inventory": (_split(row.get(str(ids["inventory"]))) or [None])[0],
                    "ips": _clean_ips(row.get(str(ids["ip"]))),
                }
            )
        return result, total_glpi

    async def disk_c(self, glpi_id: int) -> tuple[int | None, int | None]:
        """Возвращает (всего МБ, свободно МБ) для диска C:."""
        disks = await self._get(f"/Computer/{glpi_id}/Item_Disk")
        if not isinstance(disks, list):
            return None, None
        for d in disks:
            mount = str(d.get("mountpoint") or "").upper().rstrip("\\/")
            name = str(d.get("name") or "").upper().rstrip("\\/")
            if mount == "C:" or name == "C:":
                return d.get("totalsize"), d.get("freesize")
        return None, None


async def load_all() -> dict:
    """Полная загрузка: список компьютеров + диск C: по каждому."""
    async with GlpiClient() as glpi:
        computers, total_glpi = await glpi.computers()
        sem = asyncio.Semaphore(max(1, settings.glpi_concurrency))
        errors = 0

        async def fill(comp: dict) -> None:
            nonlocal errors
            async with sem:
                try:
                    total, free = await glpi.disk_c(comp["glpi_id"])
                except GlpiError as exc:
                    errors += 1
                    log.warning("Диск %s: %s", comp["name"], exc)
                    total, free = None, None
                comp["c_total_mb"] = int(total) if total else None
                comp["c_free_mb"] = int(free) if free is not None and total else None

        await asyncio.gather(*(fill(c) for c in computers))
    return {"computers": computers, "total_glpi": total_glpi, "card_errors": errors}
