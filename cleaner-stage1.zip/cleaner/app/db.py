"""Локальная база SQLite: кэш компьютеров из GLPI, статусы доступности, служебные значения."""
import json
import os
import sqlite3
import threading
from datetime import datetime

from .config import settings

_lock = threading.Lock()
_path = os.path.join(settings.data_dir, "cleaner.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS computers (
    glpi_id        INTEGER PRIMARY KEY,
    name           TEXT NOT NULL,
    location       TEXT,
    state          TEXT,
    last_inventory TEXT,
    ips            TEXT,
    c_total_mb     INTEGER,
    c_free_mb      INTEGER
);
CREATE TABLE IF NOT EXISTS status (
    glpi_id    INTEGER PRIMARY KEY,
    online     INTEGER,
    ip         TEXT,
    checked_at TEXT
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init() -> None:
    os.makedirs(settings.data_dir, exist_ok=True)
    with _lock, _connect() as conn:
        conn.executescript(SCHEMA)


def replace_computers(items: list[dict]) -> None:
    with _lock, _connect() as conn:
        conn.execute("DELETE FROM computers")
        conn.executemany(
            "INSERT INTO computers VALUES (?,?,?,?,?,?,?,?)",
            [
                (
                    c["glpi_id"], c["name"], c.get("location"), c.get("state"), c.get("last_inventory"),
                    json.dumps(c.get("ips") or []), c.get("c_total_mb"), c.get("c_free_mb"),
                )
                for c in items
            ],
        )
        conn.execute("DELETE FROM status WHERE glpi_id NOT IN (SELECT glpi_id FROM computers)")


def list_computers() -> list[dict]:
    with _lock, _connect() as conn:
        rows = conn.execute(
            """SELECT c.*, s.online, s.ip AS online_ip, s.checked_at
               FROM computers c LEFT JOIN status s ON s.glpi_id = c.glpi_id"""
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d["ips"] = json.loads(d["ips"] or "[]")
        d["online"] = None if d["online"] is None else bool(d["online"])
        result.append(d)
    return result


def save_status(items: list[tuple[int, bool, str | None]]) -> None:
    ts = now()
    with _lock, _connect() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO status VALUES (?,?,?,?)",
            [(gid, int(online), ip, ts) for gid, online, ip in items],
        )


def set_meta(**values) -> None:
    with _lock, _connect() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO meta VALUES (?,?)", [(k, json.dumps(v)) for k, v in values.items()]
        )


def get_meta() -> dict:
    with _lock, _connect() as conn:
        rows = conn.execute("SELECT key, value FROM meta").fetchall()
    return {r["key"]: json.loads(r["value"]) for r in rows}
