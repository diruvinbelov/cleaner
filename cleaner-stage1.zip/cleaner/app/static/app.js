"use strict";

const state = {
  items: [],
  meta: {},
  selected: new Set(),   // glpi_id выбранных компьютеров
  chosenIp: new Map(),   // glpi_id -> выбранный IP (если адресов несколько)
  sort: { key: "c_free_mb", dir: 1 },
  page: 1,
};

const $ = (id) => document.getElementById(id);

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function api(path, options = {}) {
  const r = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  if (r.status === 401) { location.href = "/login"; throw new Error("unauthorized"); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || `Ошибка ${r.status}`);
  return data;
}

function setStatus(text, isError = false) {
  const el = $("statusLine");
  el.textContent = text;
  el.classList.toggle("error", isError);
}

function gb(mb) { return mb == null ? "—" : (mb / 1024).toFixed(1) + " ГБ"; }
function usedPct(c) { return c.c_total_mb && c.c_free_mb != null ? (1 - c.c_free_mb / c.c_total_mb) * 100 : null; }
function parseDate(s) { if (!s) return null; const d = new Date(String(s).replace(" ", "T")); return isNaN(d) ? null : d; }
function ipOf(c) { return state.chosenIp.get(c.glpi_id) || c.online_ip || c.ips[0] || null; }

// ---------- Данные ----------

function applyData(data) {
  state.items = data.items || [];
  state.meta = data.meta || {};
  const ids = new Set(state.items.map((c) => c.glpi_id));
  for (const id of [...state.selected]) if (!ids.has(id)) state.selected.delete(id);
  render();
}

function statusText() {
  const m = state.meta;
  if (!m.last_refresh) return "Данных ещё нет — нажмите «Обновить из GLPI».";
  let t = `Готово: ${m.matched} компьютеров WS* со статусом «В работе» из ${m.total_glpi} записей GLPI. ` +
          `Ошибки карточек: ${m.card_errors}. Обновлено: ${m.last_refresh}` +
          (m.refreshed_by ? ` (${m.refreshed_by})` : "") + ".";
  if (m.last_check) t += ` Последняя проверка доступности: ${m.last_check}.`;
  return t;
}

async function load() {
  try {
    applyData(await api("/api/computers"));
    setStatus(statusText());
  } catch (e) { setStatus(e.message, true); }
}

async function refreshGlpi() {
  const btn = $("btnRefresh");
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span>Загрузка из GLPI…';
  setStatus("Загружаю компьютеры и диски из GLPI, это может занять до минуты…");
  try {
    applyData(await api("/api/glpi/refresh", { method: "POST" }));
    setStatus(statusText());
  } catch (e) { setStatus("GLPI: " + e.message, true); }
  btn.disabled = false;
  btn.textContent = "Обновить из GLPI";
}

async function check(ids = null) {
  const btns = [$("btnCheck"), $("selCheck")];
  btns.forEach((b) => (b.disabled = true));
  $("btnCheck").innerHTML = '<span class="spin"></span>Проверка…';
  setStatus(ids ? `Проверяю выбранные (${ids.length})…` : "Проверяю доступность всех компьютеров…");
  try {
    applyData(await api("/api/check", { method: "POST", body: JSON.stringify({ ids }) }));
    setStatus(statusText());
  } catch (e) { setStatus("Проверка: " + e.message, true); }
  btns.forEach((b) => (b.disabled = false));
  $("btnCheck").textContent = "Проверить компьютеры";
}

// ---------- Фильтры и сортировка ----------

function filtered() {
  const q = $("search").value.trim().toLowerCase();
  const fd = $("fDisk").value;
  const fs = $("fState").value;
  return state.items.filter((c) => {
    if (q) {
      const hay = `${c.name} ${c.location || ""} ${c.ips.join(" ")}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    const used = usedPct(c);
    if (fd === "free10" && !(c.c_free_mb != null && c.c_free_mb < 10 * 1024)) return false;
    if (fd === "free20" && !(c.c_free_mb != null && c.c_free_mb < 20 * 1024)) return false;
    if (fd === "used90" && !(used != null && used > 90)) return false;
    if (fd === "nodata" && c.c_total_mb != null) return false;
    if (fs === "on" && c.online !== true) return false;
    if (fs === "off" && c.online !== false) return false;
    if (fs === "unk" && c.online != null) return false;
    return true;
  });
}

function sortValue(c, key) {
  if (key === "used") return usedPct(c);
  if (key === "online") return c.online == null ? null : c.online ? 1 : 0;
  const v = c[key];
  return typeof v === "string" ? v.toLowerCase() : v;
}

function sorted(list) {
  const { key, dir } = state.sort;
  return [...list].sort((a, b) => {
    const va = sortValue(a, key), vb = sortValue(b, key);
    if (va == null && vb == null) return 0;
    if (va == null) return 1;   // пустые всегда внизу
    if (vb == null) return -1;
    return (va < vb ? -1 : va > vb ? 1 : 0) * dir;
  });
}

// ---------- Отрисовка ----------

function rowHtml(c, n) {
  const used = usedPct(c);
  const freeCls = c.c_free_mb == null ? "" : c.c_free_mb < 10 * 1024 ? "free-red" : c.c_free_mb < 20 * 1024 ? "free-orange" : "";
  const inv = parseDate(c.last_inventory);
  const warnDays = state.meta.inventory_warn_days || 14;
  const invOld = inv && (Date.now() - inv) / 86400000 > warnDays;
  const invHtml = c.last_inventory
    ? `<span class="${invOld ? "inv-old" : ""}" title="${invOld ? "Инвентаризация давно не обновлялась" : ""}">${invOld ? "⚠ " : ""}${esc(c.last_inventory)}</span>`
    : "—";

  let ipHtml = "—";
  if (c.ips.length === 1) ipHtml = esc(c.ips[0]);
  else if (c.ips.length > 1) {
    const cur = ipOf(c);
    ipHtml = `<select data-ip="${c.glpi_id}">` +
      c.ips.map((ip) => `<option ${ip === cur ? "selected" : ""}>${esc(ip)}</option>`).join("") + "</select>";
  }

  const st = c.online == null
    ? '<span class="st unk">Не проверялся</span>'
    : c.online ? '<span class="st on">Включён</span>' : '<span class="st off">Не отвечает</span>';

  const checked = state.selected.has(c.glpi_id);
  return `<tr class="${checked ? "selected" : ""}">
    <td><input type="checkbox" data-sel="${c.glpi_id}" ${checked ? "checked" : ""}></td>
    <td class="num">${n}</td>
    <td class="name">${esc(c.name)}</td>
    <td>${esc(c.location || "—")}</td>
    <td>${gb(c.c_total_mb)}</td>
    <td class="free ${freeCls}">${gb(c.c_free_mb)}</td>
    <td>${used == null ? "—" : `<span class="bar"><i class="${used > 95 ? "red" : ""}" style="width:${used.toFixed(0)}%"></i></span>${used.toFixed(1)}%`}</td>
    <td>${invHtml}</td>
    <td class="ip">${ipHtml}</td>
    <td>${st}</td>
  </tr>`;
}

function render() {
  const list = sorted(filtered());
  const size = parseInt($("pageSize").value, 10);
  const pages = Math.max(1, Math.ceil(list.length / size));
  state.page = Math.min(Math.max(1, state.page), pages);
  const start = (state.page - 1) * size;
  const pageItems = list.slice(start, start + size);

  $("rows").innerHTML = pageItems.length
    ? pageItems.map((c, i) => rowHtml(c, start + i + 1)).join("")
    : `<tr><td colspan="10" class="empty">${state.items.length ? "Ничего не найдено" : "Нет данных. Нажмите «Обновить из GLPI»."}</td></tr>`;

  $("pageInfo").textContent = `Страница ${state.page} / ${pages}`;
  $("prev").disabled = state.page <= 1;
  $("next").disabled = state.page >= pages;

  const checkedOnPage = pageItems.filter((c) => state.selected.has(c.glpi_id)).length;
  $("selPage").checked = pageItems.length > 0 && checkedOnPage === pageItems.length;
  $("selPage").indeterminate = checkedOnPage > 0 && checkedOnPage < pageItems.length;

  $("tMatched").textContent = state.meta.matched ?? state.items.length;
  $("tShown").textContent = list.length;
  $("tTotal").textContent = state.meta.total_glpi ?? "—";
  const checkedCount = state.items.filter((c) => c.online != null).length;
  $("tOnline").textContent = checkedCount ? state.items.filter((c) => c.online).length : "—";
  $("tSelected").textContent = state.selected.size;
  $("selCount").textContent = state.selected.size;
  $("selbar").classList.toggle("show", state.selected.size > 0);

  document.querySelectorAll("th.sort").forEach((th) => {
    th.querySelector(".arrow").textContent = th.dataset.key === state.sort.key ? (state.sort.dir > 0 ? "▲" : "▼") : "";
  });
  state.pageItems = pageItems;
}

// ---------- События ----------

$("rows").addEventListener("change", (e) => {
  const t = e.target;
  if (t.dataset.sel) {
    const id = Number(t.dataset.sel);
    t.checked ? state.selected.add(id) : state.selected.delete(id);
    render();
  } else if (t.dataset.ip) {
    state.chosenIp.set(Number(t.dataset.ip), t.value);
  }
});

$("selPage").addEventListener("change", (e) => {
  for (const c of state.pageItems || []) e.target.checked ? state.selected.add(c.glpi_id) : state.selected.delete(c.glpi_id);
  render();
});

document.querySelectorAll("th.sort").forEach((th) =>
  th.addEventListener("click", () => {
    const key = th.dataset.key;
    state.sort = state.sort.key === key ? { key, dir: -state.sort.dir } : { key, dir: 1 };
    render();
  })
);

["search", "fDisk", "fState", "pageSize"].forEach((id) =>
  $(id).addEventListener(id === "search" ? "input" : "change", () => { state.page = 1; render(); })
);

$("prev").addEventListener("click", () => { state.page--; render(); });
$("next").addEventListener("click", () => { state.page++; render(); });
$("btnRefresh").addEventListener("click", refreshGlpi);
$("btnCheck").addEventListener("click", () => check(null));
$("selCheck").addEventListener("click", () => check([...state.selected]));
$("selClear").addEventListener("click", () => { state.selected.clear(); render(); });
$("logout").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  location.href = "/login";
});

(async () => {
  try {
    const me = await api("/api/me");
    $("user").textContent = me.name || me.username;
  } catch { return; }
  load();
})();
