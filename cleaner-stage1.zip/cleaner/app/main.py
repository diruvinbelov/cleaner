"""Cleaner — веб-приложение для анализа и очистки диска C: на компьютерах пользователей."""
import asyncio
import logging
import os
import secrets
import time
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.middleware.sessions import SessionMiddleware

from . import db, glpi, netcheck
from .auth import AuthError, authenticate
from .config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("cleaner")

STATIC = Path(__file__).parent / "static"


def _secret_key() -> str:
    """SECRET_KEY из окружения, иначе генерируется один раз и хранится в /data."""
    if settings.secret_key:
        return settings.secret_key
    os.makedirs(settings.data_dir, exist_ok=True)
    path = os.path.join(settings.data_dir, "secret_key")
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    key = secrets.token_urlsafe(48)
    with open(path, "w") as f:
        f.write(key)
    os.chmod(path, 0o600)
    return key


db.init()

app = FastAPI(title="Cleaner", docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(
    SessionMiddleware,
    secret_key=_secret_key(),
    session_cookie="cleaner_session",
    max_age=settings.session_hours * 3600,
    same_site="lax",
    https_only=settings.cookie_secure,
)
app.mount("/static", StaticFiles(directory=STATIC), name="static")

_refresh_lock = asyncio.Lock()
_check_lock = asyncio.Lock()

# Простая защита от перебора паролей: не больше 5 неудачных попыток за 5 минут с одного IP
_failed: dict[str, list[float]] = {}
FAIL_LIMIT, FAIL_WINDOW = 5, 300


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "?"


def current_user(request: Request) -> dict:
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Требуется вход")
    return user


# ---------- Страницы ----------

@app.get("/healthz", include_in_schema=False)
def healthz():
    return {"ok": True}


@app.get("/", include_in_schema=False)
def index(request: Request):
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=303)
    return FileResponse(STATIC / "index.html")


@app.get("/login", include_in_schema=False)
def login_page(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/", status_code=303)
    return FileResponse(STATIC / "login.html")


# ---------- Вход / выход ----------

class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/login")
def api_login(data: LoginIn, request: Request):
    ip = _client_ip(request)
    now = time.time()
    attempts = [t for t in _failed.get(ip, []) if now - t < FAIL_WINDOW]
    if len(attempts) >= FAIL_LIMIT:
        raise HTTPException(status_code=429, detail="Слишком много попыток. Подождите 5 минут.")
    try:
        user = authenticate(data.username, data.password)
    except AuthError as exc:
        attempts.append(now)
        _failed[ip] = attempts
        raise HTTPException(status_code=401, detail=str(exc))
    _failed.pop(ip, None)
    request.session["user"] = user
    return user


@app.post("/api/logout")
def api_logout(request: Request):
    request.session.clear()
    return {"ok": True}


@app.get("/api/me")
def api_me(user: dict = Depends(current_user)):
    return user


# ---------- Компьютеры ----------

@app.get("/api/computers")
def api_computers(user: dict = Depends(current_user)):
    meta = db.get_meta()
    meta["inventory_warn_days"] = settings.inventory_warn_days
    meta["refreshing"] = _refresh_lock.locked()
    meta["checking"] = _check_lock.locked()
    return {"items": db.list_computers(), "meta": meta}


@app.post("/api/glpi/refresh")
async def api_glpi_refresh(user: dict = Depends(current_user)):
    if _refresh_lock.locked():
        raise HTTPException(status_code=409, detail="Загрузка из GLPI уже идёт")
    async with _refresh_lock:
        started = time.time()
        try:
            result = await glpi.load_all()
        except glpi.GlpiError as exc:
            log.error("GLPI: %s", exc)
            raise HTTPException(status_code=502, detail=str(exc))
        db.replace_computers(result["computers"])
        db.set_meta(
            last_refresh=db.now(),
            total_glpi=result["total_glpi"],
            matched=len(result["computers"]),
            card_errors=result["card_errors"],
            refreshed_by=user["username"],
        )
        log.info(
            "GLPI обновлён пользователем %s: %d компьютеров за %.1f c",
            user["username"], len(result["computers"]), time.time() - started,
        )
    return api_computers(user)


class CheckIn(BaseModel):
    ids: list[int] | None = None  # None = проверить все


@app.post("/api/check")
async def api_check(data: CheckIn, user: dict = Depends(current_user)):
    if _check_lock.locked():
        raise HTTPException(status_code=409, detail="Проверка уже идёт")
    async with _check_lock:
        computers = db.list_computers()
        if data.ids:
            wanted = set(data.ids)
            computers = [c for c in computers if c["glpi_id"] in wanted]
        results = await netcheck.check_many(computers)
        db.save_status(results)
        db.set_meta(last_check=db.now())
    online = sum(1 for _, ok, _ in results if ok)
    log.info("Проверка (%s): %d из %d доступны", user["username"], online, len(results))
    return api_computers(user)


@app.exception_handler(HTTPException)
async def http_error(request: Request, exc: HTTPException):
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
