"""Проверка доступности компьютеров: открыт ли SSH-порт (значит, можно подключиться для очистки)."""
import asyncio

from .config import settings


async def port_open(ip: str, port: int, timeout: float) -> bool:
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout)
    except Exception:
        return False
    writer.close()
    try:
        await writer.wait_closed()
    except Exception:
        pass
    return True


async def check_many(computers: list[dict]) -> list[tuple[int, bool, str | None]]:
    """computers: [{glpi_id, ips}] -> [(glpi_id, online, ip_который_ответил)]"""
    sem = asyncio.Semaphore(max(1, settings.check_concurrency))

    async def one(comp: dict) -> tuple[int, bool, str | None]:
        async with sem:
            for ip in comp.get("ips") or []:
                if await port_open(ip, settings.ssh_port, settings.check_timeout):
                    return comp["glpi_id"], True, ip
            return comp["glpi_id"], False, None

    return await asyncio.gather(*(one(c) for c in computers))
